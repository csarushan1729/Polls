from django.contrib import admin

# Register your models here.
from django.contrib import admin
from home.models import poll
# Register your models here.

admin.site.register(poll)
