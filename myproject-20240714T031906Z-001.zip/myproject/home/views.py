from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.template import loader
from django.contrib.auth.decorators import login_required
from home.models import poll
from home.forms import VoteForm

@login_required
def all_polls(request):
    all_polls = poll.objects.all()
    context = {'all_polls': all_polls}
    template = loader.get_template('all_polls.html')
    return HttpResponse(template.render(context, request))

@login_required
def poll_detail(request, poll_id):
    req_poll = get_object_or_404(poll, id=poll_id)
    form = VoteForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        if not request.user in req_poll.voters.all():
            selected_choice = form.cleaned_data['choice']
            if selected_choice == '1':
                req_poll.vote1 += 1
            elif selected_choice == '2':
                req_poll.vote2 += 1
            elif selected_choice == '3':
                req_poll.vote3 += 1

            req_poll.voters.add(request.user)
            req_poll.save()
            return redirect('poll-detail', poll_id=poll_id)
        else:
            # User has already voted, handle this case (optional)
            pass

    context = {'req_poll': req_poll, 'form': form}
    return render(request, 'poll_detail.html', context)
